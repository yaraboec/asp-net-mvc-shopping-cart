﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Kurs.Models
{
    public partial class Order
    {
        public Order()
        {
            PizzaContainsInOrders = new HashSet<PizzaContainsInOrder>();
        }

        public double Sum { get; set; }
        public int IdOrder { get; set; }
        public DateTime TimeOrder { get; set; }
        public double Skidka { get; set; }
        public string StatusOrder { get; set; }
        public int IdClient { get; set; }
        public int? IdAction { get; set; }

        public virtual Action IdActionNavigation { get; set; }
        public virtual User IdClientNavigation { get; set; }
        public virtual ICollection<PizzaContainsInOrder> PizzaContainsInOrders { get; set; }
    }
}
