﻿namespace Kurs.Models
{
    public class Item
    {
        public Pizza Pizza { get; set; }
        public int Quantity { get; set; }
    }
}