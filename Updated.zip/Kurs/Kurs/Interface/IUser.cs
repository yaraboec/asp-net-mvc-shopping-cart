﻿using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Interface
{
    public interface IUser
    {
        List<User> GetAllUsers();
        void InsertUser(User user);
        void UpdateUser(User user);
        void DeleteUser(User user);
        User GetById(int id);
        void Save();
    }
}
