﻿using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Interface
{
    public interface IPizza
    {
        List<Pizza> GetAllPizza();
        void InsertPizza(Pizza pizza);
        void UpdatePizza(Pizza pizza);
        void DeletePizza(Pizza pizza);
        void Save();
    }
}
