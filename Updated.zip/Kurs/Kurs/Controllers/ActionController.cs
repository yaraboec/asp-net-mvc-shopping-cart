﻿using System.Threading.Tasks;
using Kurs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Kurs.Controllers
{
    public class ActionController : Controller
    {
        private readonly KursovoyContext _db;
        
        public ActionController(KursovoyContext db)
        {
            _db = db;
        }
        
        public async Task<IActionResult> Index()
        {
            return View(await _db.Actions.ToListAsync());
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Models.Action user = await _db.Actions.FirstOrDefaultAsync(p => p.IdAction == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Models.Action act)
        {
            _db.Actions.Update(act);
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        public IActionResult Create()
        {
            return View();
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Models.Action action = await _db.Actions.FirstOrDefaultAsync(p => p.IdAction == id);
                if (action != null)
                    return View(action);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Models.Action vm)
        {

            _db.Actions.Add(vm);
            await _db.SaveChangesAsync();

            return RedirectToAction("Index");
        }
        [HttpGet]
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                Models.Action action = await _db.Actions.FirstOrDefaultAsync(p => p.IdAction == id);
                if (action != null)
                    return View(action);
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Models.Action action = await _db.Actions.FirstOrDefaultAsync(p => p.IdAction == id);
                if (action != null)
                {
                    _db.Actions.Remove(action);
                    await _db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }
    }
}