﻿using Kurs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using Kurs.Data;
using Microsoft.VisualStudio.Web.CodeGeneration;

namespace Kurs.Controllers
{
    public class HomeController : Controller
    {
        private readonly KursovoyContext _db;
        
        public HomeController(KursovoyContext db)
        {
            _db = db;
        }
        public IActionResult Index(){
        
            dynamic model = new ExpandoObject();
            PizzaActions pizza = new PizzaActions(_db);
            IngredActions ingred = new IngredActions(_db);
            PizContAction cont = new PizContAction(_db);
            model.Pizzas = pizza.GetAllPizza();
            model.Ingred = ingred.GetAllIngred();
            model.All = cont.GetAll();
            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }
        
    }
}
