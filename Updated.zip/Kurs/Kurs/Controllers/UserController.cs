﻿using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using Kurs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Kurs.Controllers
{
    public class UserController : Controller
    {
        private readonly KursovoyContext _db;
        
        public UserController(KursovoyContext db)
        {
            _db = db;
        }
        
        public async Task <IActionResult> Index()
        {

            return View(await _db.Users.ToListAsync());
        }
        public IActionResult Create()
        {
            return View();
        }
        public async Task<IActionResult> Details(int? id)
        {
            dynamic model = new ExpandoObject();
            if (id != null)
            {
                User user = await _db.Users.FirstOrDefaultAsync(p => p.IdClient == id);
                var ord = _db.Orders.Where(p => p.IdClient == id).ToList();
                model.Client = user;
                model.Order = ord;
                if (user != null)
                    return View(model);
            }
            return NotFound();
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                User user = await _db.Users.FirstOrDefaultAsync(p => p.IdClient == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(User user)
        {
            
            _db.Users.Update(user);
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task <IActionResult> Create(User vm)
        {
            vm.IdRole = 2;
            _db.Users.Add(vm);
            await _db.SaveChangesAsync();

            return RedirectToAction("Index");
        }
        [HttpGet]
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                User user = await _db.Users.FirstOrDefaultAsync(p => p.IdClient == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                User user = await _db.Users.FirstOrDefaultAsync(p => p.IdClient == id);
                if (user != null)
                {
                    _db.Users.Remove(user);
                    await _db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }
    }
}
