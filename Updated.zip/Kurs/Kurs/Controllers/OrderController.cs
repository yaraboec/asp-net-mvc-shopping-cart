﻿using Kurs.Models;
using Kurs.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Controllers
{
    public class OrderController : Controller
    {
        private readonly KursovoyContext _db;

        public OrderController(KursovoyContext db)
        {
            _db = db;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _db.Orders.ToListAsync());
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Models.Order ord = await _db.Orders.FirstOrDefaultAsync(p => p.IdOrder == id);
                if (ord != null)
                    return View(ord);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Order order)
        {
            _db.Orders.Update(order);
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Models.Order ord = await _db.Orders.FirstOrDefaultAsync(p => p.IdOrder == id);
                if (ord != null)
                    return View(ord);
            }
            return NotFound();
        }
        [HttpGet]
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                Models.Order ord = await _db.Orders.FirstOrDefaultAsync(p => p.IdOrder == id);
                if (ord != null)
                    return View(ord);
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Models.Order ord = await _db.Orders.FirstOrDefaultAsync(p => p.IdOrder == id);
                if (ord != null)
                {
                    _db.Orders.Remove(ord);
                    await _db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }
    }
}
