﻿using System.Linq;
using Kurs.Models;
using Microsoft.AspNetCore.Mvc;

namespace Kurs.Controllers
{
    public class OwnOrdersController : Controller
    {
        private readonly KursovoyContext _db;
        

        public OwnOrdersController(KursovoyContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var smb = _db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            
            return View(_db.Orders.Where(x => x.IdClient == smb.IdClient).ToList());;
        }
    }
}