﻿using Kurs.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using System.Dynamic;
using System.IO;
using Kurs.Data;
using Kurs.ViewModels;

namespace Kurs.Controllers
{
    public class AddController : Controller
    {
        private readonly KursovoyContext _db;

        string img;

        private readonly IWebHostEnvironment _webEnv;

        public AddController(KursovoyContext db, IWebHostEnvironment webEnv)
        {
            _db = db;
            _webEnv = webEnv;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _db.Pizzas.ToListAsync());
        }
        public async Task<IActionResult> AddingIngr()
        {
            dynamic model = new ExpandoObject();
            PizzaActions pizza = new PizzaActions(_db);
            IngredActions ingred = new IngredActions(_db);
            PizContAction cont = new PizContAction(_db);
            model.Pizzas = pizza.GetAllPizza();
            model.Ingred = ingred.GetAllIngred();
            model.All = cont.GetAll();
            return View(model);
        }
        [HttpGet]
        public async Task<IActionResult> EditIngr(int? id, int? id1)
        {
            if (id != null && id1 != null)
            {
                PizzaContainIngr pizza = await _db.PizzaContainIngrs.FirstOrDefaultAsync(p => p.IdPizza == id && p.IdIngredient == id1);
                if (pizza != null)
                    return View(pizza);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> EditIngr(PizzaContainIngr pizza)
        {
            _db.PizzaContainIngrs.Update(pizza);
            await _db.SaveChangesAsync();
            return RedirectToAction("AddingIngr");
        }
        public async Task<IActionResult> Adding(int id = 0)
        {
            PizzaContIngr stockMod = new PizzaContIngr();
            stockMod.Ingredient = _db.Ingredients.ToList();
            stockMod.Pizza = _db.Pizzas.ToList();

            return View(stockMod);
        }
        public async Task<IActionResult> DeleteIngr(int? id, int? id1)
        {
            if (id != null && id1 != null)
            {
                PizzaContainIngr pizza = await _db.PizzaContainIngrs.FirstOrDefaultAsync(p => p.IdPizza == id && p.IdIngredient == id1);
                if (pizza != null)
                {
                    _db.PizzaContainIngrs.Remove(pizza);
                    await _db.SaveChangesAsync();
                    return RedirectToAction( "AddingIngr");
                }
            }
            return NotFound();
        }
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                Pizza pizza = await _db.Pizzas.FirstOrDefaultAsync(p => p.IdPizza == id);
                if (pizza != null)
                    return View(pizza);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Pizza pizza = await _db.Pizzas.FirstOrDefaultAsync(p => p.IdPizza == id);
                if (pizza != null)
                {
                    _db.Pizzas.Remove(pizza);
                    await _db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }
        [HttpPost]
        public IActionResult Create(PizzaViewModel vm)
        {

            string stringFileName = UploadedFile(vm);

            img = stringFileName;

            var pizza = new Pizza
            {
                Img = stringFileName,
                Name = vm.Name,
                Weight = 0,
                PriceWork = vm.PriceWork,
                ResultPrice = 0,
            };
            _db.Pizzas.Add(pizza);
            _db.SaveChanges();

            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Adding(PizzaContainIngr ingrcont)
        {
            _db.PizzaContainIngrs.Add(ingrcont);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Pizza piz = await _db.Pizzas.FirstOrDefaultAsync(p => p.IdPizza == id);
                PizzaEditViewModel pizEdit = new PizzaEditViewModel
                {
                    IdPizza = piz.IdPizza,
                    Name = piz.Name,
                    PriceWork = piz.PriceWork,
                    ExistImg = piz.Img
                };
                return View(pizEdit);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(PizzaEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                Pizza pizza = _db.Pizzas.Where(c => c.IdPizza == model.IdPizza).FirstOrDefault();
                pizza.Name = model.Name;
                pizza.PriceWork = model.PriceWork;
                if (model.Img != null)
                {

                    if (model.ExistImg != null)
                    {
                        string filePath = Path.Combine(_webEnv.WebRootPath,
                            "Img", model.ExistImg);
                        System.IO.File.Delete(filePath);
                    }
                    pizza.Img = UploadedFile(model);
                }
                _db.Pizzas.Update(pizza);
                await _db.SaveChangesAsync();
                return RedirectToAction("index");
            }

            return View(model);
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Pizza pizza = await _db.Pizzas.FirstOrDefaultAsync(p => p.IdPizza == id);
                var sost =  _db.PizzaContainIngrs.AsEnumerable();
                var ingr = _db.Ingredients.AsEnumerable();
                foreach (var il in sost)
                {
                    if(il.IdPizza == pizza.IdPizza)
                        foreach (var an in ingr)
                        {
                            if(il.IdIngredient == an.IdIngredient)
                            ViewData["sostav"] +=string.Format(an.Name + " ");
                        }
                }
                if (pizza != null)
                    return View(pizza);
            }
            return NotFound();
        }

        private string UploadedFile(PizzaViewModel model)
        {
            string uniqueFileName = null;

            if (model.Img != null)
            {
                string uploadsFolder = Path.Combine(_webEnv.WebRootPath,"Img");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Img.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.Img.CopyTo(fileStream);
                }
            }
            return uniqueFileName;
        }

        public IActionResult Create()
        {
            return View();
        }
    }
}
