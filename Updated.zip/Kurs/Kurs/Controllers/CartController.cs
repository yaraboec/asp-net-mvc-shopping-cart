﻿using System.Collections.Generic;
using System.Linq;
using Kurs.Data;
using Kurs.Helpers;
using Kurs.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Kurs.Controllers
{
    public class CartController : Controller
    {
        private readonly KursovoyContext _db;
        
        public CartController(KursovoyContext db)
        {
            _db = db;
        }
        [Authorize]
        public IActionResult Index()
        {
            var cart = Session.GetObj<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            if(ViewBag.cart != null)
                ViewBag.total = cart.Sum(x => x.Pizza.ResultPrice * x.Quantity);
            return View();
        }

        private int IsEx(int id)
        {
            List<Item> cart = Session.GetObj<List<Item>>(HttpContext.Session, "cart");
            for (int i = 0; i < cart.Count; i++)
            {
                if (cart[i].Pizza.IdPizza.Equals(id))
                {
                    return i;
                }
            }
            return -1;
        }
        [Authorize]
        public IActionResult Buy(int id)
        {
            PizzaActions action = new PizzaActions(_db);
            if (Session.GetObj<List<Item>>(HttpContext.Session, "cart") == null)
            {
                List<Item> cart = new List<Item>();
                cart.Add(new Item { Pizza = action.GetById(id), Quantity = 1 });
                Session.SetObj(HttpContext.Session, "cart", cart);
            }
            else
            {
                List<Item> cart = Session.GetObj<List<Item>>(HttpContext.Session, "cart");
                int index = IsEx(id);
                if(index != -1)
                {
                    cart[index].Quantity++;
                }
                else
                {
                    cart.Add(new Item { Pizza = action.GetById(id), Quantity = 1 });
                }
                Session.SetObj(HttpContext.Session, "cart", cart);
            }
            return RedirectToAction("Index");

        }
        public IActionResult Remove(int id)
        {
            List<Item> cart = Session.GetObj<List<Item>>(HttpContext.Session, "cart");
            int index = IsEx(id);
            cart.RemoveAt(index);
            Session.SetObj(HttpContext.Session, "cart", cart);
            return RedirectToAction("Index");
        }
        public IActionResult checkout(Cart abc)
        {
            var cart = Session.GetObj<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            ViewBag.total = cart.Sum(item => item.Pizza.ResultPrice * item.Quantity);
            PizContAction piz = new PizContAction(_db);
            Order ord = new Order();
            var per = _db.Actions.Where(c => c.BeginAction < System.DateTime.Now.TimeOfDay && c.EndAction > System.DateTime.Now.TimeOfDay).ToList();
            double sum = 0;
            var user = _db.Users.FirstOrDefault(x => x.Email == User.Identity.Name);
            ord.IdClient = user.IdClient;
            ord.Sum = ViewBag.total;
            ord.Skidka = 1;
            foreach(var dl in per)
            {
                ord.IdAction = dl.IdAction;
                ord.Skidka = dl.PercentSkidki + user.Skidka;
                TempData["Action"] = dl.Name;
                TempData["Begin"] = dl.BeginAction.ToString();
                TempData["End"] = dl.EndAction.ToString();
            }
            ord.TimeOrder = System.DateTime.Now;
            ord.StatusOrder = "В Обработке";
            _db.Orders.Add(ord);
            _db.SaveChanges();

            foreach(var item in cart)
            {
                PizzaContainsInOrder inv = new PizzaContainsInOrder();

                inv.IdPizza = item.Pizza.IdPizza;
                inv.Amount = item.Quantity;
                inv.IdOrder = piz.MaxValue();
                _db.PizzaContainsInOrders.Add(inv);
                _db.SaveChanges();
            }
            Session.SetObj(HttpContext.Session, "cart", null);
            TempData["msg"] = "Заказ успешно совершен!";
            TempData.Keep();

            return RedirectToAction("Index","Home");
        }
    }
}