﻿using Kurs.Interface;
using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Data
{
    public class PizzaActions : IPizza
    {
        private readonly KursovoyContext _db;

        public PizzaActions(KursovoyContext db)
        {
            _db = db;
        }
        public void DeletePizza(Pizza pizza)
        {
            _db.Pizzas.Remove(pizza);
        }

        public List<Pizza> GetAllPizza()
        {
            return _db.Pizzas.ToList();
        }

        public void InsertPizza(Pizza pizza)
        {
            _db.Pizzas.Add(pizza);
        }

        public void Save()
        {
            _db.SaveChanges();
        }

        public void UpdatePizza(Pizza pizza)
        {
            _db.Pizzas.Update(pizza);
        }
        public Pizza GetById(int id)
        {
            return _db.Pizzas.Where(e => e.IdPizza == id).FirstOrDefault();
        }
    }
}
