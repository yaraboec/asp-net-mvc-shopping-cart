﻿using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Data
{
    public class IngredActions
    {
        private readonly KursovoyContext _db;

        public IngredActions(KursovoyContext db)
        {
            _db = db;
        }
        public List<Ingredient> GetAllIngred()
        {
            return _db.Ingredients.ToList();
        }
    }
}
