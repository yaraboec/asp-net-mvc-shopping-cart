﻿using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Data
{
    public class OrdContPiz
    {
        private readonly KursovoyContext _db;

        public OrdContPiz(KursovoyContext db)
        {
            _db = db;
        }
        public List<PizzaContainsInOrder> GetAll()
        {
            return _db.PizzaContainsInOrders.ToList();
        }

    }
}
