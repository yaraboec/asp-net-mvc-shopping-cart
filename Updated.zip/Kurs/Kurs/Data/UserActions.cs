﻿using Kurs.Interface;
using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Data
{
    public class UserActions : IUser
    {
        private readonly KursovoyContext _db;

        public UserActions(KursovoyContext db)
        {
            _db = db;
        }
        public void DeleteUser(User user)
        {
            _db.Users.Remove(user);
        }

        public List<User> GetAllUsers()
        {
            return _db.Users.ToList();
        }

        public void InsertUser(User client)
        {
            _db.Users.Add(client);
        }

        public void Save()
        {
            _db.SaveChanges();
        }

        public void UpdateUser(User client)
        {
            _db.Users.Update(client);
        }
        public User GetById(int id)
        {
            return _db.Users.Where(e => e.IdClient == id).FirstOrDefault();
        }
    }
}
