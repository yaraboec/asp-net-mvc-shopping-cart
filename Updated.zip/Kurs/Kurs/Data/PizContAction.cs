﻿using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Data
{
    public class PizContAction
    {
        private readonly KursovoyContext _db;

        public PizContAction(KursovoyContext db)
        {
            _db = db;
        }

        public List<PizzaContainIngr> GetAll()
        {
            return _db.PizzaContainIngrs.ToList();
        }
        public int MaxValue()
        {
            int max;
            max = _db.Orders.Max(x => x.IdOrder);
            return max;
        }

    }
}
