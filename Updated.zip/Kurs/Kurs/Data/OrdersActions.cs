﻿using Kurs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Data
{
    public class OrdersActions
    {
        private readonly KursovoyContext _db;

        public OrdersActions(KursovoyContext db)
        {
            _db = db;
        }
        public List<Order> GetOrders()
        {
            return _db.Orders.ToList();
        }
    }
}
