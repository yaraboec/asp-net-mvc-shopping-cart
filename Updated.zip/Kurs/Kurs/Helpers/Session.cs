﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.Helpers
{
    public static class Session
    {
        public static void SetObj(this ISession sess, string key, object value)
        {
            sess.SetString(key, JsonConvert.SerializeObject(value));

        }
        public static T GetObj<T>(this ISession sess, string key)
        {
            var value = sess.GetString(key);
            return value == null ? default : JsonConvert.DeserializeObject<T>(value);
        }
    }
}
