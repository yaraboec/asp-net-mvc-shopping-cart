﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.ViewModels
{
    public class UserViewModel
    {
        public string Name { get; set; }
        public string SurName { get; set; }
        public double Skidka { get; set; }
        public string Number { get; set; }
        public string Email { get; set; }
    }
}
