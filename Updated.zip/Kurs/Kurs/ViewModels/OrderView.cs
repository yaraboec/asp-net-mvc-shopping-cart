﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kurs.ViewModels
{
    public class OrderView
    {
        public int IdOrder { get; set; }
        public string StatusOrder { get; set; }
    }
}
