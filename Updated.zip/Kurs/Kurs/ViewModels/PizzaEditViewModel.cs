﻿namespace Kurs.ViewModels
{
    public class PizzaEditViewModel : PizzaViewModel
    {
        public int IdPizza { get; set; }
        public string ExistImg { get; set; }
    }
}